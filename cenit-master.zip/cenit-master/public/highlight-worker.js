onmessage = function(event) {
  postMessage('process');
}