PrawnRails.config do |config|
  config.skip_page_creation = true
end