ActiveSupport::Inflector.inflections do |inflect|
  inflect.irregular 'sms', 'sms'
end
