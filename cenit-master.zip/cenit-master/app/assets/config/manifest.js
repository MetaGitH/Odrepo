//= link_directory ../javascript .js
//= link_directory ../stylesheets .css