class ThreadToken < Cenit::BasicToken

end