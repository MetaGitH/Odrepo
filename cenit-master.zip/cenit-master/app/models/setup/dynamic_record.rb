module Setup
  module DynamicRecord
  end
end
