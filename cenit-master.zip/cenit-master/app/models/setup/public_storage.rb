module Setup
  class PublicStorage
    include BuildInFileType

    public_by_default true
  end
end
