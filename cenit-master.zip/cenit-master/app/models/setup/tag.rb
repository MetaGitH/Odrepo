module Setup
  class Tag
    include SharedEditable
    include NamespaceNamed

  end
end
