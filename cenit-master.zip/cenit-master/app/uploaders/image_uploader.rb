class ImageUploader < GridFsUploader
  include RmagickUploader
end