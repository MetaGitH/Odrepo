class AccountImageUploader < AccountUploader
  include RmagickUploader
end
