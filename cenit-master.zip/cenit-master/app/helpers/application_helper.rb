module ApplicationHelper
 # TODO Remove this file
end
