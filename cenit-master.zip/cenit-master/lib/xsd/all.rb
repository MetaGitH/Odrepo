module Xsd
  class All < Container

    tag 'all'

  end
end