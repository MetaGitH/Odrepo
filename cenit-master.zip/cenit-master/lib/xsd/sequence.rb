module Xsd
  class Sequence < Container

    tag 'sequence'

  end
end