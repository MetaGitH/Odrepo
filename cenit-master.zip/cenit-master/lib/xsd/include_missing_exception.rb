module Xsd
  class IncludeMissingException  < Exception

  end
end