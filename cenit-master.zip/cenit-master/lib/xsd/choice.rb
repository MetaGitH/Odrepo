module Xsd
  class Choice < Container

    tag 'choice'

  end
end