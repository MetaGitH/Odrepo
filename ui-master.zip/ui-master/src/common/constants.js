export const Hidden = { hidden: true };

export const NotHidden = { hidden: false };
