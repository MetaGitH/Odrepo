import { Liquid } from "liquidjs";

const LiquidEngine = new Liquid();

export default LiquidEngine;
