const FormContext = Object.freeze({
    edit: 'edit',
    new: 'new'
});

export default FormContext;
