import commonTaskConfig from "./commonTaskConfig";

const DataTypeGeneration = commonTaskConfig('Data Type Generation'); // TODO Not yet supported in API v3

export default DataTypeGeneration;
