import commonTaskConfig from "./commonTaskConfig";

const Submission = commonTaskConfig('Submission'); // TODO Not yet supported in API v3

export default Submission;
