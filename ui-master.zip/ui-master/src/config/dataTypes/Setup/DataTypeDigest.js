import commonTaskConfig from "./commonTaskConfig";

const DataTypeDigest = commonTaskConfig('Data Digest'); // TODO Deprecated from API v2

export default DataTypeDigest;
