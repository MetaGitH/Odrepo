import commonTaskConfig from "./commonTaskConfig";

const SchemasImport = commonTaskConfig('Schemas Import'); // TODO Not yet supported in API v3

export default SchemasImport;
