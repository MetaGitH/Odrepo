import commonTaskConfig from "./commonTaskConfig";

const DataTypeExpansion = commonTaskConfig('Data Type Expansion'); // TODO Not yet supported in API v3

export default DataTypeExpansion;
