import React from 'react';
import commonTaskConfig from "./commonTaskConfig";

const CollectionSharing = commonTaskConfig('Collection Sharing');

export default CollectionSharing;
