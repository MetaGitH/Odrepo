const fields = ['property_name', 'location'];

export default {
    title: 'Property location',
    actions: {
        new: {
            fields
        },
        edit: {
            fields
        }
    }
};
