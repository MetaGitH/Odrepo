import commonTaskConfig from "./commonTaskConfig";

const Deletion = commonTaskConfig('Deletion');

export default Deletion;
