import commonTaskConfig from "./commonTaskConfig";

const AsynchronousPersistence = commonTaskConfig('Asynchronous Persistence');

export default AsynchronousPersistence;
