import commonTaskConfig from "./commonTaskConfig";

const NamespaceCollection = commonTaskConfig('Namespace Collection'); // TODO Not yet supported in API v3

export default NamespaceCollection;
