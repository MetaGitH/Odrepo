import React from 'react';
import FilterFilledIcon from "../../../icons/FilterFilledIcon";

export default {
    title: 'Filter',
    icon: <FilterFilledIcon/>
};
