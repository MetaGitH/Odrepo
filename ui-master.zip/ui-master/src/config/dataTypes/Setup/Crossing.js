import React from 'react';
import commonTaskConfig from "./commonTaskConfig";

const Crossing = commonTaskConfig('Crossing');

export default Crossing;
