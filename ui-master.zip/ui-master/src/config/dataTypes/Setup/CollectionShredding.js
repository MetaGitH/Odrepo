import React from 'react';
import commonTaskConfig from "./commonTaskConfig";

const CollectionShredding = commonTaskConfig('Collection Shredding');

export default CollectionShredding;
