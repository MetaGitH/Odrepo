import React from 'react';
import commonTaskConfig from "./commonTaskConfig";
import ViewerControl from "../../../components/ViewerControl";

const HookDataProcessing = commonTaskConfig('Hook Processing', {
    hook: {}
});

export default HookDataProcessing;
