
const TenantTypeSelector = { namespace: '', name: 'Account' };

export default TenantTypeSelector;
