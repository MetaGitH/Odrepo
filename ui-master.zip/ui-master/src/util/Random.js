
const Random = {
    string: () => Math.random().toString(36).substring(7)
};

export default Random;