window.appConfig = {
    REACT_APP_USE_ENVIRONMENT_CONFIG: "true",
    REACT_APP_TIMEOUT_SPAN: "300000",
    REACT_APP_APP_ID: "admin",
    REACT_APP_LOCALHOST: "http://localhost:3002", // "https://app.cenit.io",
    REACT_APP_CENIT_HOST: "http://localhost:3000", // "https://server.cenit.io",
};
